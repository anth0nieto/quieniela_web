<?php

namespace quiniela\Http\Controllers;

use Illuminate\Http\Request;

use quiniela\Http\Requests;
use Session;
use Redirect;
use Carbon\Carbon;
use quiniela\Http\Requests\QuinielaRequest;
use quiniela\Quiniela;
use quiniela\UserQuiniela;
use quiniela\UserTransaccion;
use Auth;

use DB;

class QuinielaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $quinielas = Quiniela::paginate(12);
        return view('quiniela.index',compact('quinielas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('quiniela.create');
    }

    public function showQuinielas()
    {
        $quinielas = Quiniela::paginate(8);
        $username = Auth::user()->username;
        $user_quinielas = DB::table('user_quinielas')->where('username','=',$username)->get();
        return view('user.showQuinielas',compact('quinielas'));
    }

    

    public function store(QuinielaRequest $request)
    {
        Quiniela::create([
            'nombre'=> $request['nombre'],
            'costo'=> $request['costo'],
            'usuarios'=> $request['usuarios'],
            'ganadores'=> $request['ganadores'],
            'fecha_inicio'=> $request['fecha_inicio'],
            'fecha_finalizacion'=> $request['fecha_finalizacion'],
            ]);
    
        Session::flash('message','Quiniela creada exitosamente');
        return Redirect::to('/quiniela');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {   
        $quiniela = Quiniela::find($id);
        return view('user.preinscripcion',compact('quiniela'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $quiniela = Quiniela::find($id);
        return view('quiniela.edit',['quiniela'=>$quiniela]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update($id,QuinielaRequest $request)
    {
        $quiniela = Quiniela::find($id);
        $quiniela->fill($request->all());
        $quiniela->save();
        Session::flash('message','Quiniela editada exitosamente');
        return Redirect::to('/quiniela');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Quiniela::destroy($id);

        Session::flash('message','Quiniela eliminada exitosamente');
        return Redirect::to('/quiniela');
    }

    public function inscribir($id){

        $quiniela = Quiniela::find($id);
        return redirect('quiniela.inscripcion',compact('quiniela'));
    }

  public function verMiQuiniela()
    {

        $ranking = array();
        $aaa = 'Inscrito';

        $id_quiniela = ($_GET['id']);
        $usuarios = DB::table('user_quinielas')
                         ->where('user_quinielas.status','=',$aaa)
                         ->select('user_quinielas.id','user_quinielas.username')
                         ->get();

        
        foreach ($usuarios as $usuario)
        {
            

            $puntos = 0;
            $puntos_equipos = 0;
            $resultados = 0;
            $ganador = 0;
            $equipos = 0;

            for ($i=-1; $i < 6; $i++) 
            {
                
                $resultados_usuarios = DB::table('pronosticos')
                                    //->join('partidos','partidos.id_partido','=','pronosticos.id_partido')
                                    ->join('user_quinielas','user_quinielas.id','=','pronosticos.id_user')
                                    ->where('pronosticos.id_user','=',$usuario->id)
                                    ->where('pronosticos.fase','=',$i)
                                    ->select('pronosticos.id_partido','pronosticos.id_quiniela','pronosticos.goles_local','pronosticos.goles_visitante','pronosticos.id_user')                                 
                                    ->get();
                

                if (!empty($resultados_usuarios))
                {
                        foreach ($resultados_usuarios as $resultado)
                        {   
                           
                            $equi_loc = substr($resultado->id_partido, 0, 3);
                            $equi_vis = substr($resultado->id_partido, 3, 5);

                            if ($i == 0 or $i == 1) 
                            {
                               $resultados_reales = DB::table('resultado_admins')
                                            ->join('partidos','partidos.id_partido','=','resultado_admins.id_partido')
                                            ->where('resultado_admins.id_quiniela','=',$id_quiniela)
                                            ->where('resultado_admins.id_partido','=',$resultado->id_partido)
                                            ->where('resultado_admins.fase','=',$i)
                                            ->select('resultado_admins.id_partido','resultado_admins.id_quiniela','resultado_admins.goles_local','resultado_admins.goles_visitante','partidos.id_local','partidos.id_visitante')                                 
                                            ->get();
                            }
                            elseif ($i == 2 or $i == 3 or $i == 4 or $i == 5 )
                            {
                                $resultados_reales = DB::table('resultado_admins')
                                            ->join('partidos','partidos.id_partido','=','resultado_admins.id_partido')
                                            ->where('resultado_admins.id_quiniela','=',$id_quiniela)
                                            ->where('resultado_admins.fase','=',$i)
                                            ->select('resultado_admins.id_partido','resultado_admins.id_quiniela','resultado_admins.goles_local','resultado_admins.goles_visitante','partidos.id_local','partidos.id_visitante')                                 
                                            ->get();
                            }
                            

                           
                            $equipos_octavos_local = DB::table('partidos')
                                            ->join('equipos','equipos.id_equipo','=','partidos.id_local')
                                            ->where('partidos.id_quiniela','=',$id_quiniela)
                                            ->where('partidos.fase_grupo','=',2)
                                            ->select('equipos.nombre')                                 
                                            ->get();

                            $equipos_octavos_visitante = DB::table('partidos')
                                            ->join('equipos','equipos.id_equipo','=','partidos.id_visitante')
                                            ->where('partidos.id_quiniela','=',$id_quiniela)
                                            ->where('partidos.fase_grupo','=',2)
                                            ->select('equipos.nombre')                                 
                                            ->get();

                           


                            // Equipos que el usuario acerto en octavos
                            if($i == -1)
                            {
                                    foreach ($equipos_octavos_visitante as $local) 
                                    {
                                        if (($resultado->id_partido == $local->nombre)) 
                                        {
                                           $puntos += 2;
                                           $puntos_equipos += 2;
                                           $equipos += 1;
                                        }
                                    }

                                    foreach ($equipos_octavos_local as $visitante) 
                                    {
                                        if (($resultado->id_partido == $visitante->nombre)) 
                                        {
                                           $puntos += 2;
                                           $puntos_equipos += 2;
                                           $equipos += 1;
                                        }
                                    }
                            }
                                    

                            if(!empty($resultados_reales))
                            {

                                if($i == 0)
                                {
                                    // Resultado
                                    if(($resultado->goles_local == $resultados_reales[0]->goles_local) and ($resultado->goles_visitante == $resultados_reales[0]->goles_visitante))
                                    {
                                        $puntos += 3;
                                        $resultados += 1;
                                    }
                                    
                                    // Ganador
                                    elseif(   (($resultado->goles_local - $resultado->goles_visitante) < 0 ) and (($resultados_reales[0]->goles_local - $resultados_reales[0]->goles_visitante) < 0 ) )
                                    {
                                        $puntos += 1;
                                        $ganador += 1;
                                    }

                                    // Ganador
                                    elseif(   (($resultado->goles_local - $resultado->goles_visitante) > 0 ) and (($resultados_reales[0]->goles_local - $resultados_reales[0]->goles_visitante) > 0 ) )
                                    {
                                        $puntos += 1;
                                        $ganador += 1;
                                    }

                                    // Epate ---> igual es ganador
                                    elseif((($resultado->goles_local - $resultado->goles_visitante) == 0 ) and (($resultados_reales[0]->goles_local - $resultados_reales[0]->goles_visitante) ==0 )) 
                                    {
                                        $puntos += 1;
                                        $ganador += 1;
                                    }
                                }
                                // 8vos
                                elseif($i == 1)
                                {
                                    // Resultado
                                    if(($resultado->goles_local == $resultados_reales[0]->goles_local) and ($resultado->goles_visitante == $resultados_reales[0]->goles_visitante))
                                    {
                                        $puntos += 3;
                                        $resultados += 1;
                                    }
                                    
                                    // Ganador
                                    if(   (($resultado->goles_local - $resultado->goles_visitante) < 0 ) and (($resultados_reales[0]->goles_local - $resultados_reales[0]->goles_visitante) < 0 ) )
                                    {
                                        $puntos += 1;
                                        $ganador += 1;
                                    }

                                    // Ganador
                                    elseif(   (($resultado->goles_local - $resultado->goles_visitante) > 0 ) and (($resultados_reales[0]->goles_local - $resultados_reales[0]->goles_visitante) > 0 ) )
                                    {
                                        $puntos += 1;
                                        $ganador += 1;
                                    }

                                    // Epate ---> igual es ganador
                                    elseif((($resultado->goles_local - $resultado->goles_visitante) == 0 ) and (($resultados_reales[0]->goles_local - $resultados_reales[0]->goles_visitante) ==0 )) 
                                    {
                                        $puntos += 1;
                                        $ganador += 1;
                                    }
                                }
                                // 4tos
                                elseif($i == 2)
                                {
                                    $equipos_octavos_local = DB::table('partidos')
                                            ->join('equipos','equipos.id_equipo','=','partidos.id_local')
                                            ->where('partidos.id_quiniela','=',$id_quiniela)
                                            ->where('partidos.fase_grupo','=',3)
                                            ->select('equipos.nombre')                                 
                                            ->get();

                                    $equipos_octavos_visitante = DB::table('partidos')
                                            ->join('equipos','equipos.id_equipo','=','partidos.id_visitante')
                                            ->where('partidos.id_quiniela','=',$id_quiniela)
                                            ->where('partidos.fase_grupo','=',3)
                                            ->select('equipos.nombre')                                 
                                            ->get();

                                    foreach ($equipos_octavos_visitante as $local) 
                                    {
                                        if (($resultado->id_partido == $local->nombre)) 
                                        {
                                           $puntos += 4;
                                        }
                                    }

                                    foreach ($equipos_octavos_local as $visitante) 
                                    {
                                        if (($resultado->id_partido == $visitante->nombre)) 
                                        {
                                           $puntos += 4;
                                        }
                                    }

                                    foreach ($resultados_reales as $resultados_admin) 
                                    {

                                        // Resultado
                                        if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                                 and ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis))
                                        {
                                            if(($resultado->goles_local == $resultados_admin->goles_local and $resultado->goles_visitante == $resultados_admin->goles_visitante)
                                                   or  ($resultado->goles_local == $resultados_admin->goles_visitante and $resultado->goles_visitante == $resultados_admin->goles_local ))
                                            {
                                                $puntos += 5;
                                                $resultados += 1;
                                            }
                                            
                                        }
                                        
                                        // Ganador Visitante
                                        if(   ($resultados_admin->goles_local - $resultados_admin->goles_visitante < 0 ) and 
                                                (($resultado->goles_local - $resultado->goles_visitante) < 0 or ($resultado->goles_local - $resultado->goles_visitante) > 0) )
                                        { 
                                            if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                            or ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis)) 
                                            { 
                                                $puntos += 3;
                                                $ganador += 1;
                                            }
                                        }

                                        // Ganador Local
                                        elseif(   ($resultados_admin->goles_local - $resultados_admin->goles_visitante > 0 ) 
                                                    and ( ($resultado->goles_local - $resultado->goles_visitante) > 0  or ($resultado->goles_local - $resultado->goles_visitante < 0)))
                                        { 

                                            if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                                 or ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis))
                                            { 
                                                $puntos += 3;
                                                $ganador += 1;

                                            }
                                        }

                                        // Epate ---> igual es ganador
                                        elseif((($resultados_admin->goles_local - $resultados_admin->goles_visitante) == 0 ) and (($resultado->goles_local - $resultado->goles_visitante) ==0 )) 
                                        {
                                            if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                                 or ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis))
                                            {
                                                $puntos += 3;
                                                $ganador += 1;

                                            }
                                        }
                                    }    

                                }
                                // Semifinal
                                elseif($i == 3)
                                {
                                    $equipos_octavos_local = DB::table('partidos')
                                            ->join('equipos','equipos.id_equipo','=','partidos.id_local')
                                            ->where('partidos.id_quiniela','=',$id_quiniela)
                                            ->where('partidos.fase_grupo','=',4)
                                            ->select('equipos.nombre')                                 
                                            ->get();

                                    $equipos_octavos_visitante = DB::table('partidos')
                                            ->join('equipos','equipos.id_equipo','=','partidos.id_visitante')
                                            ->where('partidos.id_quiniela','=',$id_quiniela)
                                            ->where('partidos.fase_grupo','=',4)
                                            ->select('equipos.nombre')                                 
                                            ->get();

                                    foreach ($equipos_octavos_visitante as $local) 
                                    {
                                        if (($resultado->id_partido == $local->nombre)) 
                                        {
                                           $puntos += 6;
                                        }
                                    }

                                    foreach ($equipos_octavos_local as $visitante) 
                                    {
                                        if (($resultado->id_partido == $visitante->nombre)) 
                                        {
                                           $puntos += 6;
                                        }
                                    }

                                    foreach ($resultados_reales as $resultados_admin) 
                                    {

                                        // Resultado
                                        if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                                 and ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis))
                                        {
                                            if(($resultado->goles_local == $resultados_admin->goles_local and $resultado->goles_visitante == $resultados_admin->goles_visitante)
                                                   or  ($resultado->goles_local == $resultados_admin->goles_visitante and $resultado->goles_visitante == $resultados_admin->goles_local ))
                                            {
                                                $puntos += 6;
                                                $resultados += 1;
                                            }
                                            
                                        }
                                        
                                        // Ganador Visitante
                                        if(   ($resultados_admin->goles_local - $resultados_admin->goles_visitante < 0 ) and 
                                                (($resultado->goles_local - $resultado->goles_visitante) < 0 or ($resultado->goles_local - $resultado->goles_visitante) > 0) )
                                        { 
                                            if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                            or ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis)) 
                                            { 
                                                $puntos += 4;
                                                $ganador += 1;
                                            }
                                        }

                                        // Ganador Local
                                        elseif(   ($resultados_admin->goles_local - $resultados_admin->goles_visitante > 0 ) 
                                                    and ( ($resultado->goles_local - $resultado->goles_visitante) > 0  or ($resultado->goles_local - $resultado->goles_visitante < 0)))
                                        { 

                                            if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                                 or ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis))
                                            { 
                                                $puntos += 4;
                                                $ganador += 1;

                                            }
                                        }

                                        // Epate ---> igual es ganador
                                        elseif((($resultados_admin->goles_local - $resultados_admin->goles_visitante) == 0 ) and (($resultado->goles_local - $resultado->goles_visitante) ==0 )) 
                                        {
                                            if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                                 or ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis))
                                            {
                                                $puntos += 4;
                                                $ganador += 1;

                                            }
                                        }
                                    }                
                                }

                                // Final
                                elseif($i == 4)
                                { 

                                    $equipos_octavos_local = DB::table('partidos')
                                            ->join('equipos','equipos.id_equipo','=','partidos.id_local')
                                            ->where('partidos.id_quiniela','=',$id_quiniela)
                                            ->where('partidos.fase_grupo','=',5)
                                            ->select('equipos.nombre')                                 
                                            ->get();

                                    $equipos_octavos_visitante = DB::table('partidos')
                                            ->join('equipos','equipos.id_equipo','=','partidos.id_visitante')
                                            ->where('partidos.id_quiniela','=',$id_quiniela)
                                            ->where('partidos.fase_grupo','=',5)
                                            ->select('equipos.nombre')                                 
                                            ->get();

                                    foreach ($equipos_octavos_visitante as $local) 
                                    {
                                        if (($resultado->id_partido == $local->nombre)) 
                                        {
                                           $puntos += 8;
                                        }
                                    }

                                    foreach ($equipos_octavos_local as $visitante) 
                                    {
                                        if (($resultado->id_partido == $visitante->nombre)) 
                                        {
                                           $puntos += 8;
                                        }
                                    }

                                    foreach ($resultados_reales as $resultados_admin) 
                                    {

                                        // Resultado
                                        if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                                 and ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis))
                                        {
                                            if(($resultado->goles_local == $resultados_admin->goles_local and $resultado->goles_visitante == $resultados_admin->goles_visitante)
                                                   or  ($resultado->goles_local == $resultados_admin->goles_visitante and $resultado->goles_visitante == $resultados_admin->goles_local ))
                                            {
                                                $puntos += 7;
                                                $resultados += 1;
                                            }
                                            
                                        }
                                        
                                        // Ganador Visitante
                                        if(   ($resultados_admin->goles_local - $resultados_admin->goles_visitante < 0 ) and 
                                                (($resultado->goles_local - $resultado->goles_visitante) < 0 or ($resultado->goles_local - $resultado->goles_visitante) > 0) )
                                        { 
                                            if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                            or ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis)) 
                                            { 
                                                $puntos += 15;
                                                $ganador += 1;
                                            }
                                        }

                                        // Ganador Local
                                        elseif(   ($resultados_admin->goles_local - $resultados_admin->goles_visitante > 0 ) 
                                                    and ( ($resultado->goles_local - $resultado->goles_visitante) > 0  or ($resultado->goles_local - $resultado->goles_visitante < 0)))
                                        { 

                                            if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                                 or ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis))
                                            { 
                                                $puntos += 15;
                                                $ganador += 1;

                                            }
                                        }

                                        // Epate ---> igual es ganador
                                        elseif((($resultados_admin->goles_local - $resultados_admin->goles_visitante) == 0 ) and (($resultado->goles_local - $resultado->goles_visitante) ==0 )) 
                                        {
                                            if( ($resultados_admin->id_local == $equi_loc or $resultados_admin->id_local == $equi_vis)
                                                 or ($resultados_admin->id_visitante == $equi_loc or $resultados_admin->id_visitante == $equi_vis))
                                            {
                                                $puntos += 15;
                                                $ganador += 1;

                                            }
                                        }
                                    }    
                                } 

                                // Campeon
                                elseif($i == 5)
                                {


                                    $equipos_octavos_local = DB::table('partidos')
                                            ->join('equipos','equipos.id_equipo','=','partidos.id_local')
                                            ->where('partidos.id_quiniela','=',$id_quiniela)
                                            ->where('partidos.fase_grupo','=',6)
                                            ->select('equipos.nombre','equipos.id_equipo')                                 
                                            ->get();



                                    foreach ($equipos_octavos_local as $local) 
                                    {
                                        if (($resultado->id_partido == $local->id_equipo)) 
                                        {
                                           $puntos += 15;
                                        }
                                    }

                                }
                            }
                        } 
                       
                }
            }
                
            
            array_push($ranking, array($usuario->username,$puntos,$usuario->id,$ganador,$resultados,$puntos_equipos,$equipos));
        }

        
        // $puntuaciones = DB::table('puntuaciones')
        //                                     ->join('user_quinielas','puntuaciones.id_user','=','user_quinielas.id')
        //                                     ->where('puntuaciones.id_quiniela','=',$id_quiniela)
        //                                     ->select('user_quinielas.username','puntuaciones.ptos','puntuaciones.ganadores','puntuaciones.resultados','user_quinielas.id')
        //                                     ->orderBy('puntuaciones.ptos', 'desc')
        //                                     ->get();

        $quiniela = DB::table('quinielas')
                      ->where('id','=',$id_quiniela)
                      ->first();


        for ($i=0; $i < count($ranking); $i++)
        { 
            for ($j=$i; $j < count($ranking); $j++)
            { 
                if($ranking[$i][1] < $ranking[$j][1])
                {
                    $aux = $ranking[$i];
                    $ranking[$i] = $ranking[$j];
                    $ranking[$j] = $aux;
                }
            }
        }
        return view('user.verQuiniela',compact('ranking','quiniela'));
    }
}
